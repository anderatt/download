# Projeto 9 - IA Generativa e RAG Para App de Sistema Inteligente de Busca em Documentos - Backend e API
# Módulo da API Para o LLM

# Import
import os


#Servidor de Aplicação
app_server_ip = '192.168.0.5'

#Servidor de APIs do Django
api_server_ip = '192.168.0.5'
#api_server_ip = 'localhost'
api_server_port = '8080'


'''
Para futuro esse modulo deve ser reescrito usando um cofre de senhas
'''
