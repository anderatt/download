﻿# Projeto de Inteligência Artificial - APP

## Criação da camada de interface com o usuário

### Configurações para colocar a aplicação feita em Streamlit para rodar em um servidor linux Ubuntu com uma conta de serviço específica:

>Instalação do Ubuntu
* O Ubuntu pode ser instalado em modo server, sem a necessidade de interface gráfica

>Criar uma conta de serviço iaapp
* sudo adduser iaapp

>Adicionar os privilégios à conta de serviço iaapp
* sudo adduser iaapp

>Adicionar os privilégios à conta de serviço iaapp
* sudo usermod -aG staff iaapp
* sudo usermod -aG users iaapp

>Adicionar a conta de serviço iaapp a no arquivo sudoers
* Editar o arquivo /etc/sudoers e adicionar a linha abaixo
* iaapp   ALL=(ALL:ALL) ALL

