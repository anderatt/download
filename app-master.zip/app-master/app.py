import streamlit as st
from login.page import show_login



def main():
    if 'token' not in st.session_state:
        show_login()
    else:
        st.title('Flix App')

        menu_option = st.sidebar.selectbox(
            'Selecione uma opção',
            ['Início', 'GPT', 'Llama3 8B', 'RDBMS']
        )

        if menu_option == 'Início':
            st.title('Home')

        if menu_option == 'GPT':
            st.title('GPT')

        if menu_option == 'Llama3 8B':
            st.title('LLAMA38B')

        if menu_option == 'RDBMS':
            st.title('GPT')

if __name__ == '__main__':
    main()
